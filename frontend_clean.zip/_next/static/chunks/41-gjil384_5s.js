(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,31278,e=>{"use strict";let a=(0,e.i(75254).default)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);e.s(["Loader2",0,a],31278)},63488,e=>{"use strict";let a=(0,e.i(75254).default)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]]);e.s(["Mail",0,a],63488)},43432,e=>{"use strict";let a=(0,e.i(75254).default)("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]);e.s(["Phone",0,a],43432)},95468,e=>{"use strict";let a=(0,e.i(75254).default)("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);e.s(["CheckCircle2",0,a],95468)},84614,e=>{"use strict";let a=(0,e.i(75254).default)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);e.s(["User",0,a],84614)},51737,e=>{"use strict";let a=(0,e.i(75254).default)("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]);e.s(["ShieldAlert",0,a],51737)},55436,e=>{"use strict";let a=(0,e.i(75254).default)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);e.s(["Search",0,a],55436)},3281,e=>{"use strict";let a=(0,e.i(75254).default)("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);e.s(["Printer",0,a],3281)},15829,e=>{"use strict";let a={Branca:{bg:"bg-white",border:"border-zinc-300",text:"text-zinc-950 font-bold",progressClass:"bg-white border border-gray-300"},"Branca/Amarela":{bg:"bg-white",border:"border-amber-400",text:"text-zinc-950 font-bold",centerStripe:"bg-amber-400",stripe:"bg-amber-400",progressClass:"bg-white"},Amarela:{bg:"bg-amber-400",border:"border-amber-500",text:"text-zinc-950 font-bold",progressClass:"bg-amber-400"},"Amarela/Laranja":{bg:"bg-amber-400",border:"border-orange-500",text:"text-zinc-950 font-bold",centerStripe:"bg-orange-500",stripe:"bg-orange-500",progressClass:"bg-amber-400"},Laranja:{bg:"bg-orange-500",border:"border-orange-600",text:"text-white font-bold",progressClass:"bg-orange-500"},"Laranja/Verde":{bg:"bg-orange-500",border:"border-emerald-600",text:"text-white font-bold",centerStripe:"bg-emerald-600",stripe:"bg-emerald-600",progressClass:"bg-orange-500"},Verde:{bg:"bg-emerald-600",border:"border-emerald-700",text:"text-white font-bold",progressClass:"bg-emerald-600"},"Verde/Azul":{bg:"bg-emerald-600",border:"border-blue-600",text:"text-white font-bold",centerStripe:"bg-blue-600",stripe:"bg-blue-600",progressClass:"bg-emerald-600"},Azul:{bg:"bg-blue-600",border:"border-blue-700",text:"text-white font-bold",progressClass:"bg-blue-600"},"Azul/Vermelha":{bg:"bg-blue-600",border:"border-red-600",text:"text-white font-bold",centerStripe:"bg-red-500",stripe:"bg-red-500",progressClass:"bg-blue-600"},Vermelha:{bg:"bg-red-600",border:"border-red-700",text:"text-white font-bold",progressClass:"bg-red-500"},Marrom:{bg:"bg-amber-900",border:"border-amber-700",text:"text-amber-100 font-bold",progressClass:"bg-amber-800"},"Marrom I":{bg:"bg-amber-900",border:"border-amber-700",text:"text-amber-100 font-bold",tipStripe:"bg-white",stripe:"bg-white",progressClass:"bg-amber-900"},"Marrom II":{bg:"bg-amber-900",border:"border-amber-700",text:"text-amber-100 font-bold",tipStripe:"bg-amber-400",stripe:"bg-amber-400",progressClass:"bg-amber-950"},"Preta/Branca":{bg:"bg-zinc-950",border:"border-zinc-700",text:"text-white font-bold",centerStripe:"bg-white",stripe:"bg-white",progressClass:"bg-zinc-950"},"Preta (Júnior)":{bg:"bg-zinc-950",border:"border-zinc-700",text:"text-white font-bold",centerStripe:"bg-white",stripe:"bg-white",progressClass:"bg-zinc-950"},Preta:{bg:"bg-zinc-950",border:"border-amber-500",text:"text-amber-400 font-bold",progressClass:"bg-zinc-950 border border-zinc-700"},"Preta I":{bg:"bg-zinc-950",border:"border-amber-500",text:"text-amber-400 font-bold",progressClass:"bg-zinc-950 border border-zinc-700"},"Preta II":{bg:"bg-zinc-950",border:"border-amber-500",text:"text-amber-400 font-bold",progressClass:"bg-zinc-950 border border-gold/40"}};e.s(["FAIXAS",0,["Branca","Branca/Amarela","Amarela","Amarela/Laranja","Laranja","Laranja/Verde","Verde","Verde/Azul","Azul","Azul/Vermelha","Vermelha","Marrom","Marrom I","Marrom II","Preta/Branca","Preta I","Preta II"],"FAIXAS_ADULTO",0,["Branca","Amarela","Laranja","Verde","Azul","Vermelha","Marrom","Marrom I","Marrom II","Preta","Preta I","Preta II"],"FAIXAS_INFANTIL",0,["Branca/Amarela","Amarela","Amarela/Laranja","Laranja","Laranja/Verde","Verde","Verde/Azul","Azul","Azul/Vermelha","Vermelha","Marrom","Marrom I","Marrom II","Preta/Branca"],"obterEstiloFaixa",0,function(e){if(!e)return{bg:"bg-white",border:"border-zinc-300",text:"text-zinc-950 font-bold",progressClass:"bg-white"};let s=e.trim();if(a[s])return a[s];let t=s.toLowerCase();return t.includes("preta/branca")||t.includes("preta branca")||t.includes("preta júnior")||t.includes("preta jr")||t.includes("preta junior")?a["Preta/Branca"]:t.includes("branca/amarela")||t.includes("branca amarela")?a["Branca/Amarela"]:t.includes("amarela/laranja")||t.includes("amarela laranja")?a["Amarela/Laranja"]:t.includes("laranja/verde")||t.includes("laranja verde")?a["Laranja/Verde"]:t.includes("verde/azul")||t.includes("verde azul")?a["Verde/Azul"]:t.includes("azul/vermelha")||t.includes("azul vermelha")?a["Azul/Vermelha"]:t.includes("preta")||t.includes("dan")?{bg:"bg-zinc-950",border:"border-amber-500",text:"text-amber-400 font-bold",progressClass:"bg-zinc-950"}:t.includes("amarela")?{bg:"bg-amber-400",border:"border-amber-500",text:"text-zinc-950 font-bold",progressClass:"bg-amber-400"}:t.includes("laranja")?{bg:"bg-orange-500",border:"border-orange-600",text:"text-white font-bold",progressClass:"bg-orange-500"}:t.includes("verde")?{bg:"bg-emerald-600",border:"border-emerald-700",text:"text-white font-bold",progressClass:"bg-emerald-600"}:t.includes("azul")?{bg:"bg-blue-600",border:"border-blue-700",text:"text-white font-bold",progressClass:"bg-blue-600"}:t.includes("vermelha")?{bg:"bg-red-600",border:"border-red-700",text:"text-white font-bold",progressClass:"bg-red-600"}:t.includes("marrom")?{bg:"bg-amber-900",border:"border-amber-700",text:"text-amber-100 font-bold",progressClass:"bg-amber-800"}:t.includes("branca")?{bg:"bg-white",border:"border-zinc-300",text:"text-zinc-950 font-bold",progressClass:"bg-white"}:{bg:"bg-zinc-800",border:"border-zinc-600",text:"text-white font-bold",progressClass:"bg-zinc-800"}}])},51004,e=>{"use strict";var a=e.i(43476),s=e.i(71645),t=e.i(32341),r=e.i(51737),i=e.i(31278),l=e.i(55436),o=e.i(95468),n=e.i(84614),d=e.i(64030),c=e.i(63488),x=e.i(43432),p=e.i(3281),m=e.i(78583),b=e.i(15829);let u="https://api.gojuryukaratekai.com.br";function g(e){let s=(0,b.obterEstiloFaixa)(e);return(0,a.jsxs)("div",{className:`relative flex items-center justify-between px-2.5 py-1 rounded border text-[9px] font-black uppercase tracking-wider ${s.bg} ${s.border} ${s.text} shadow-sm overflow-hidden h-[22px] min-w-[95px] select-none`,children:[s.centerStripe&&(0,a.jsx)("div",{className:`absolute inset-x-0 top-1/2 -translate-y-1/2 h-1.5 ${s.centerStripe} pointer-events-none opacity-90`}),(0,a.jsx)("span",{className:"relative z-10 truncate pr-1 drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]",children:e||"Branca"}),s.tipStripe?(0,a.jsx)("div",{className:`relative z-10 w-2.5 h-full ${s.tipStripe}`,title:"Ponteira de Graduação"}):s.centerStripe?null:(0,a.jsx)("div",{className:"relative z-10 w-1 h-full bg-zinc-950/20"})]})}e.s(["default",0,function(){let{usuario:e,tipo:f,isAdmin:h}=(0,t.useAuth)(),[v,j]=(0,s.useState)([]),[z,N]=(0,s.useState)(!0),[w,y]=(0,s.useState)(""),[_,C]=(0,s.useState)("todos"),[k,A]=(0,s.useState)([]),[$,S]=(0,s.useState)(null),[F,P]=(0,s.useState)(null),[M,I]=(0,s.useState)(""),[D,R]=(0,s.useState)(""),[L,E]=(0,s.useState)(""),[K,G]=(0,s.useState)(!1),T=async()=>{try{let e=await fetch(`${u}/api/atletas`,{credentials:"include"});if(!e.ok)throw Error("Falha ao obter atletas da API");let a=await e.json();j(a.atletas||[])}catch(e){console.error("Erro ao carregar atletas, usando dados emulados:",e),j([{id:"st-1",nome:"Pedro Oliveira",email:"pedro.oliveira@grkk.com.br",telefone:"(71) 98888-2001",faixa:"Branca",status:"ativo",filial_nome:"Filial Salvador Centro"},{id:"st-2",nome:"Lucas Almeida",email:"lucas.almeida@grkk.com.br",telefone:"(71) 98888-2002",faixa:"Amarela",status:"ativo",filial_nome:"Filial Salvador Centro"},{id:"pending-athlete-id",nome:"Atleta Pendente de Teste",email:"atleta-pendente@grkk.com.br",telefone:"71988888888",faixa:"Branca",status:"pendente",filial_nome:"GRKK CABULA"}])}finally{N(!1)}},B=async()=>{try{let e=await fetch(`${u}/api/filiais`,{credentials:"include"});if(e.ok){let a=await e.json();A(a.filiais||[])}}catch(e){console.error("Erro ao carregar filiais na área administrativa:",e)}};(0,s.useEffect)(()=>{T(),B()},[]);let V=async(e,a)=>{try{if(!(await fetch(`${u}/api/atletas/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({status:a})})).ok)throw Error("Erro ao alterar status do atleta");j(v.map(s=>s.id===e?{...s,status:a}:s))}catch(s){j(v.map(s=>s.id===e?{...s,status:a}:s))}},U=async(e,a)=>{try{if(!(await fetch(`${u}/api/atletas/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({documentos_entregues:a})})).ok)throw Error("Erro ao atualizar status dos documentos do atleta");j(v.map(s=>s.id===e?{...s,documentos_entregues:a}:s))}catch(e){alert(e.message||"Erro ao atualizar documentos")}},O=async e=>{if(confirm("Tem certeza que deseja excluir permanentemente este atleta?"))try{if(!(await fetch(`${u}/api/atletas/${e}`,{method:"DELETE",credentials:"include"})).ok)throw Error("Erro ao excluir atleta");j(v.filter(a=>a.id!==e))}catch(a){j(v.filter(a=>a.id!==e))}},Y=async e=>{if(e.preventDefault(),$){G(!0);try{let e=k.find(e=>e.id===D),a=e?e.nome:"Dojo Central / Sem Filial";(await fetch(`${u}/api/atletas/${$.id}`,{method:"PATCH",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({faixa:M,filial_id:D||null,filial_nome:D?a:null,federacao:L||null})})).ok&&(j(v.map(e=>e.id===$.id?{...e,faixa:M,filial_id:D||void 0,filial_nome:D?a:"Dojo Central / Sem Filial",federacao:L||void 0}:e)),S(null))}catch(s){let e=k.find(e=>e.id===D),a=e?e.nome:"Dojo Central / Sem Filial";j(v.map(e=>e.id===$.id?{...e,faixa:M,filial_id:D||void 0,filial_nome:D?a:"Dojo Central / Sem Filial",federacao:L||void 0}:e)),S(null)}finally{G(!1)}}},H=v.filter(e=>{let a=e.nome.toLowerCase().includes(w.toLowerCase())||e.email.toLowerCase().includes(w.toLowerCase()),s="todos"===_||e.status===_;return a&&s});return z?(0,a.jsx)("div",{className:"flex items-center justify-center min-h-[70vh]",children:(0,a.jsx)(i.Loader2,{className:"w-8 h-8 text-primary animate-spin"})}):"admin"!==f&&"filial"!==f?(0,a.jsxs)("div",{className:"flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4",children:[(0,a.jsx)(r.ShieldAlert,{className:"w-16 h-16 text-red-500"}),(0,a.jsx)("h2",{className:"text-xl font-bold text-white font-cinzel",children:"Acesso Negado"}),(0,a.jsx)("p",{className:"text-zinc-500 text-sm",children:"Apenas administradores e filiais homologadas podem acessar este painel."})]}):(0,a.jsxs)("main",{className:"p-4 sm:p-6 lg:p-8 xl:p-10 space-y-8 w-full max-w-7xl mx-auto",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("h1",{className:"text-2xl font-black text-white font-cinzel tracking-wider",children:"Gestão de Atletas"}),(0,a.jsx)("p",{className:"text-xs text-zinc-500 mt-0.5 uppercase tracking-widest font-semibold",children:"Homologação de cadastros e graduações"})]}),(0,a.jsxs)("div",{className:"flex flex-col md:flex-row items-center justify-between gap-4",children:[(0,a.jsx)("div",{className:"flex items-center gap-1.5 bg-zinc-900 p-1 border border-zinc-800 rounded-xl w-full md:w-auto",children:["todos","ativo","pendente"].map(e=>(0,a.jsx)("button",{onClick:()=>C(e),className:`flex-1 md:flex-none px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition cursor-pointer ${_===e?"bg-primary text-white":"text-zinc-500 hover:text-white"}`,children:"todos"===e?"Todos":"ativo"===e?"Ativos":"Pendentes"},e))}),(0,a.jsxs)("div",{className:"relative w-full md:max-w-xs",children:[(0,a.jsx)("input",{type:"text",placeholder:"Buscar por nome ou e-mail...",value:w,onChange:e=>y(e.target.value),className:"w-full pl-9 pr-4 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white outline-none"}),(0,a.jsx)(l.Search,{size:14,className:"absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"})]})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:[H.map(e=>(0,a.jsxs)("div",{className:"bg-zinc-900 border border-zinc-800/80 rounded-2xl p-5 space-y-4 flex flex-col justify-between",children:[(0,a.jsxs)("div",{className:"space-y-3",children:[(0,a.jsxs)("div",{className:"flex items-start justify-between",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsx)("div",{className:"w-10 h-10 bg-zinc-950 border border-zinc-850 rounded-xl flex items-center justify-center text-zinc-400",children:(0,a.jsx)(n.User,{size:18})}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h3",{className:"text-sm font-bold text-white leading-tight",children:e.nome}),(0,a.jsx)("p",{className:"text-[10px] text-zinc-500",children:e.filial_nome||"Dojo Central"})]})]}),(0,a.jsxs)("div",{className:"flex flex-col items-end gap-1",children:[(0,a.jsx)("span",{className:`px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider rounded-md border ${"ativo"===e.status?"bg-emerald-500/10 text-emerald-400 border-emerald-500/20":"pendente"===e.status?"bg-amber-500/10 text-amber-400 border-amber-500/20":"bg-red-500/10 text-red-400 border-red-500/20"}`,children:e.status}),"pendente"===e.status&&!e.cpf&&(0,a.jsx)("span",{className:"px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider rounded-md border bg-red-950/40 text-red-400 border-red-500/30",title:"Cadastro sem CPF preenchido",children:"Falta CPF"})]})]}),(0,a.jsxs)("div",{className:"space-y-1.5 pt-2 border-t border-zinc-800/50",children:[(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(c.Mail,{size:11,className:"text-zinc-650"})," ",e.email]}),(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(x.Phone,{size:11,className:"text-zinc-650"})," ",e.telefone||"Não informado"]}),(0,a.jsxs)("div",{className:"text-[10px] text-zinc-400 flex items-center justify-between gap-1.5 pt-1 border-t border-zinc-800/10",children:[(0,a.jsxs)("span",{className:"flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(d.Trophy,{size:11,className:"text-zinc-650"})," Graduação:"]}),g(e.faixa)]}),(0,a.jsxs)("div",{className:"text-[10px] text-zinc-400 flex items-center justify-between gap-1.5 pt-1 border-t border-zinc-800/10",children:[(0,a.jsxs)("span",{className:"flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(m.FileText,{size:11,className:"text-zinc-650"})," Documentos:"]}),(0,a.jsx)("button",{type:"button",onClick:()=>U(e.id,!e.documentos_entregues),className:`px-2 py-0.5 rounded text-[8px] font-bold uppercase border transition duration-300 cursor-pointer ${e.documentos_entregues?"bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20":"bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20"}`,children:e.documentos_entregues?"Entregues":"Pendentes"})]})]})]}),(0,a.jsxs)("div",{className:"flex flex-col gap-2 pt-4 border-t border-zinc-800/40",children:["pendente"===e.status&&(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsxs)("button",{onClick:()=>V(e.id,"ativo"),className:"flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5",children:[(0,a.jsx)(o.CheckCircle2,{size:12})," Homologar"]}),(0,a.jsx)("button",{onClick:()=>V(e.id,"inativo"),className:"flex-1 py-2 bg-zinc-950 hover:bg-red-950/40 border border-zinc-800 hover:border-red-900/30 text-zinc-400 hover:text-red-400 rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5",children:"Negar"})]}),"ativo"===e.status&&(0,a.jsx)("button",{onClick:()=>V(e.id,"inativo"),className:"w-full py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Suspender Atleta"}),"inativo"===e.status&&(0,a.jsx)("button",{onClick:()=>V(e.id,"ativo"),className:"w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center flex items-center justify-center gap-1",children:"Re-homologar"}),(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsx)("button",{onClick:()=>P(e),className:"flex-1 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Ver Ficha"}),(0,a.jsx)("button",{onClick:()=>{S(e),I(e.faixa),R(e.filial_id||""),E(e.federacao||"")},className:"flex-1 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Faixa / Dojo"})]}),(0,a.jsx)("button",{onClick:()=>O(e.id),className:"w-full py-1.5 bg-red-950/20 hover:bg-red-650 border border-red-900/20 hover:border-red-500 text-red-400 hover:text-white rounded-xl text-[9px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Excluir Atleta"})]})]},e.id)),0===H.length&&(0,a.jsx)("div",{className:"col-span-full py-12 text-center text-zinc-500 text-xs",children:"Nenhum atleta encontrado."})]}),$&&(0,a.jsx)("div",{className:"fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-zinc-900 border border-zinc-850 rounded-2xl w-full max-w-sm p-6 relative",children:[(0,a.jsx)("h3",{className:"text-base font-bold text-white font-cinzel mb-1",children:"Dados Técnicos do Atleta"}),(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 uppercase tracking-wider mb-5",children:["Atleta: ",(0,a.jsx)("strong",{className:"text-white",children:$.nome})]}),(0,a.jsxs)("form",{onSubmit:Y,className:"space-y-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-[10px] font-bold text-zinc-450 uppercase mb-1.5",children:"Faixa / Graduação"}),(0,a.jsxs)("select",{value:M,onChange:e=>I(e.target.value),className:"w-full px-3.5 py-2.5 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white outline-none focus:border-gold",children:[(0,a.jsx)("optgroup",{label:"── Divisão Infantil ──",children:b.FAIXAS_INFANTIL.map(e=>(0,a.jsx)("option",{value:e,children:e},`inf-${e}`))}),(0,a.jsx)("optgroup",{label:"── Divisão Adulto ──",children:b.FAIXAS_ADULTO.map(e=>(0,a.jsx)("option",{value:e,children:e},`adu-${e}`))})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-[10px] font-bold text-zinc-450 uppercase mb-1.5",children:"Dojo / Filial"}),(0,a.jsxs)("select",{value:D,onChange:e=>R(e.target.value),className:"w-full px-3.5 py-2.5 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white outline-none focus:border-gold",children:[(0,a.jsx)("option",{value:"",children:"Dojo Central (Nenhuma Filial)"}),k.map(e=>(0,a.jsx)("option",{value:e.id,children:e.nome},e.id))]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-[10px] font-bold text-zinc-450 uppercase mb-1.5",children:"Federação"}),(0,a.jsxs)("select",{value:L,onChange:e=>E(e.target.value),className:"w-full px-3.5 py-2.5 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white outline-none focus:border-gold",children:[(0,a.jsx)("option",{value:"",children:"Não filiado a nenhuma federação"}),(0,a.jsx)("option",{value:"FKBA",children:"Filiado a FKBA"}),(0,a.jsx)("option",{value:"IOGKF Brasil",children:"Filiado a IOGKF Brasil"})]})]}),(0,a.jsxs)("div",{className:"flex gap-2.5 pt-2",children:[(0,a.jsx)("button",{type:"button",onClick:()=>S(null),className:"flex-1 py-2.5 bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer",children:"Cancelar"}),(0,a.jsx)("button",{type:"submit",disabled:K,className:"flex-1 py-2.5 bg-gradient-to-r from-red-600 to-red-800 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition hover:scale-[1.02] cursor-pointer flex items-center justify-center",children:K?(0,a.jsx)(i.Loader2,{size:12,className:"animate-spin"}):"Confirmar"})]})]})]})}),F&&(0,a.jsx)("div",{className:"fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-zinc-950 border border-zinc-900 rounded-3xl w-full max-w-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto",children:[(0,a.jsx)("div",{className:"absolute -top-12 -right-12 w-32 h-32 bg-primary/5 rounded-full blur-2xl pointer-events-none"}),(0,a.jsxs)("div",{className:"flex justify-between items-start border-b border-zinc-900 pb-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center gap-3",children:[(0,a.jsx)("h3",{className:"text-xl font-bold text-white font-cinzel tracking-wider",children:F.nome}),g(F.faixa)]}),(0,a.jsx)("p",{className:"text-[10px] text-zinc-500 uppercase tracking-widest font-semibold mt-1",children:"Ficha Cadastral e Ficha Médica"})]}),(0,a.jsx)("button",{onClick:()=>P(null),className:"w-8 h-8 rounded-xl bg-zinc-900/50 flex items-center justify-center text-zinc-400 hover:text-white border border-zinc-800/80 hover:border-zinc-700 transition cursor-pointer",children:"×"})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("h4",{className:"text-xs font-bold text-gold font-cinzel tracking-wider uppercase",children:"Dados Pessoais e Contato"}),(0,a.jsxs)("div",{className:"space-y-2.5 text-xs",children:[(0,a.jsxs)("p",{className:"text-zinc-400",children:["CPF: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.cpf?F.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Data de Nascimento: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.data_nascimento?F.data_nascimento.split("-").reverse().join("/"):"Não informada"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Idade: ",(0,a.jsxs)("strong",{className:"text-white",children:[F.data_nascimento?new Date().getFullYear()-new Date(F.data_nascimento).getFullYear():"—"," anos"]})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Sexo: ",(0,a.jsx)("strong",{className:"text-white",children:"M"===F.sexo?"Masculino":"F"===F.sexo?"Feminino":"Outro"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Celular: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.telefone||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["E-mail: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.email})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Dojo / Filial: ",(0,a.jsx)("strong",{className:"text-white",children:F.filial_nome||"Dojo Central"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Federação: ",(0,a.jsx)("strong",{className:"text-white",children:F.federacao?F.federacao.startsWith("Filiado")?F.federacao:`Filiado a ${F.federacao}`:"Não filiado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Já praticou artes marciais antes?: ",(0,a.jsx)("strong",{className:"text-white",children:F.ja_praticou_artes_marciais||(F.nome_professor?"Sim":"Não")})]}),("Sim"===F.ja_praticou_artes_marciais||F.nome_professor)&&(0,a.jsxs)("div",{className:"bg-zinc-900/40 p-2.5 rounded-xl border border-zinc-800/80 space-y-1 my-1",children:[(0,a.jsxs)("p",{className:"text-zinc-400",children:["Sensei / Professor: ",(0,a.jsx)("strong",{className:"text-white",children:F.nome_professor||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Arte Marcial: ",(0,a.jsx)("strong",{className:"text-white",children:F.arte_marcial||"Karate"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Estilo: ",(0,a.jsx)("strong",{className:"text-white",children:F.estilo||"Goju-Ryu"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Academia / Clube: ",(0,a.jsx)("strong",{className:"text-white",children:F.academia_clube||"Associação Goju-Ryu Karate Kai"})]})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Endereço: ",(0,a.jsxs)("strong",{className:"text-white leading-relaxed",children:[F.endereco||"Não cadastrado"," ",F.cidade?`, ${F.cidade} - ${F.uf||"BA"}`:""]})]})]})]}),(0,a.jsxs)("div",{className:"space-y-6",children:[F.data_nascimento&&new Date().getFullYear()-new Date(F.data_nascimento).getFullYear()<18?(0,a.jsxs)("div",{className:"bg-zinc-900/40 border border-gold/15 rounded-2xl p-4 space-y-3",children:[(0,a.jsx)("h4",{className:"text-[11px] font-bold text-gold font-cinzel tracking-wider uppercase",children:"Responsável Legal (Menor)"}),(0,a.jsxs)("div",{className:"space-y-2 text-xs",children:[(0,a.jsxs)("p",{className:"text-zinc-400",children:["Nome: ",(0,a.jsx)("strong",{className:"text-white",children:F.responsavel_nome||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["CPF: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_cpf?F.responsavel_cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Celular: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_telefone||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["E-mail: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_email||"Não informado"})]})]})]}):null,(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("h4",{className:"text-xs font-bold text-emerald-400 font-cinzel tracking-wider uppercase",children:"Ficha Médica do Atleta"}),(0,a.jsxs)("div",{className:"grid grid-cols-3 gap-3.5 bg-zinc-900/40 border border-emerald-500/10 rounded-2xl p-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-0.5",children:"Tipo Sanguíneo / Rh"}),(0,a.jsxs)("p",{className:"text-white font-mono text-xs font-bold",children:[F.medico_tipo_sanguineo||"—"," ",F.medico_fator_rh||""]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-0.5",children:"Peso / Altura"}),(0,a.jsxs)("p",{className:"text-white font-mono text-xs font-bold",children:[F.fisico_peso?`${F.fisico_peso} kg`:"—"," / ",F.fisico_altura?`${F.fisico_altura} m`:"—"]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-0.5",children:"Cartão SUS"}),(0,a.jsx)("p",{className:"text-white font-mono text-xs truncate",children:F.medico_sus||"Não informado"})]}),(0,a.jsxs)("div",{className:"col-span-3 border-t border-zinc-900/80 pt-2.5",children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-0.5",children:"Contato de Emergência"}),(0,a.jsxs)("p",{className:"text-white font-medium text-xs",children:[F.medico_emergencia_nome||"Não informado",F.medico_emergencia_telefone?` (${F.medico_emergencia_telefone})`:""]})]})]}),(0,a.jsxs)("div",{className:"space-y-3.5 text-xs",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Alergias Gerais"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_alergias||"Nenhuma alergia relatada."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Alergia a Medicamentos"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_alergia_medicamento||"Nenhuma alergia a medicamentos relatada."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Medicamento de Uso Contínuo"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:"Sim"===F.medico_medicacao_uso?`Sim: ${F.medico_medicacao_lista||"Não especificado"}`:"Não faz uso de medicamento contínuo."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Plano de Saúde"}),(0,a.jsx)("p",{className:"text-white bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_plano||"Sem informações de convênio médico."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Restrições Físicas / Médicas"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_restricoes||"Nenhuma restrição relatada."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Diagnósticos Clínicos"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_diagnosticos||"Nenhum diagnóstico clínico relatado."})]})]})]})]})]}),(0,a.jsxs)("div",{className:"flex justify-end gap-3 pt-4 border-t border-zinc-900",children:[(0,a.jsxs)("button",{onClick:()=>{let e,a,s,t,r,i;return e=F.data_nascimento?F.data_nascimento.split("-").reverse().join("/"):"Não informada",a=F.cpf?F.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado",s=F.data_nascimento?new Date().getFullYear()-new Date(F.data_nascimento).getFullYear():"—",t=F.data_nascimento&&new Date().getFullYear()-new Date(F.data_nascimento).getFullYear()<18,r=F.responsavel_cpf?F.responsavel_cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado",void((i=window.open("","_blank"))&&(i.document.write(`
      <html>
      <head>
        <title>Ficha Cadastral e M\xe9dica - ${F.nome}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Inter:wght@400;600;800&display=swap');
          body {
            font-family: 'Inter', sans-serif;
            color: #111;
            background-color: #fff;
            padding: 20px;
            font-size: 10px;
            line-height: 1.35;
          }
          .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 15px;
          }
          .header-logo {
            height: 55px;
            object-fit: contain;
          }
          .header-text {
            text-align: center;
            flex: 1;
            margin: 0 15px;
          }
          .header-text h1 {
            font-family: 'Cinzel', serif;
            font-size: 16px;
            margin: 0 0 3px 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-weight: 800;
          }
          .header-text p {
            font-size: 8.5px;
            margin: 0;
            font-weight: 600;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            color: #444;
          }
          .section-title {
            font-family: 'Cinzel', serif;
            font-size: 10px;
            font-weight: bold;
            border-bottom: 1px solid #111;
            padding-bottom: 2px;
            margin-top: 15px;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
          }
          .grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
          }
          .grid-3 {
            grid-template-columns: repeat(3, 1fr);
          }
          .grid-full {
            grid-column: span 2;
          }
          .grid-full-3 {
            grid-column: span 3;
          }
          .field {
            display: flex;
            flex-direction: column;
          }
          .label {
            font-size: 7.5px;
            font-weight: 800;
            text-transform: uppercase;
            color: #555;
            margin-bottom: 2px;
          }
          .value {
            font-size: 10px;
            font-weight: 600;
            color: #000;
            padding: 5px 8px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 5px;
            min-height: 12px;
          }
          .value-large {
            min-height: 32px;
          }
          .signature-area {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
            gap: 25px;
          }
          .signature-box {
            flex: 1;
            text-align: center;
          }
          .signature-line {
            border-top: 1px solid #111;
            margin-top: 25px;
            padding-top: 4px;
            font-size: 7.5px;
            font-weight: 600;
            text-transform: uppercase;
          }
          .list-rules {
            margin: 0;
            padding-left: 12px;
          }
          .list-rules li {
            margin-bottom: 2px;
          }
          @media print {
            body { padding: 10px; }
            .section-title { margin-top: 10px; }
            .signature-area { margin-top: 20px; }
          }
        </style>
      </head>
      <body>
        <div class="header-container" style="justify-content: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px;">
          <div class="header-text" style="text-align: center;">
            <img src="${window.location.origin}/logo.png" alt="GRKK" style="height: 55px; margin-bottom: 5px; display: block; margin-left: auto; margin-right: auto;" />
            <h1>Associa\xe7\xe3o Goju-Ryu Karate Kai</h1>
            <p>Ficha de Matr\xedcula & Ficha M\xe9dica de Emerg\xeancia</p>
          </div>
        </div>

        <div class="section-title">Dados Gerais e T\xe9cnicos</div>
        <div class="grid grid-3">
          <div class="field grid-full-3">
            <span class="label">Nome Completo</span>
            <span class="value">${F.nome}</span>
          </div>
          <div class="field">
            <span class="label">N\xba de Registro da Federa\xe7\xe3o</span>
            <span class="value">${F.registro_federacao||"Pendente de homologação"}</span>
          </div>
          <div class="field">
            <span class="label">Gradua\xe7\xe3o Atual (Faixa/N\xedvel)</span>
            <span class="value">${F.faixa}</span>
          </div>
          <div class="field">
            <span class="label">Academia / Dojo / Filial</span>
            <span class="value">${F.filial_nome||"Dojo Central"}</span>
          </div>
          <div class="field">
            <span class="label">Professor Respons\xe1vel</span>
            <span class="value">${F.nome_professor||"Não informado"}</span>
          </div>
          <div class="field">
            <span class="label">Arte Marcial</span>
            <span class="value">${F.arte_marcial||"Karate"}</span>
          </div>
          <div class="field">
            <span class="label">Estilo</span>
            <span class="value">${F.estilo||"Goju-Ryu"}</span>
          </div>
          <div class="field">
            <span class="label">Entidade de Pr\xe1tica</span>
            <span class="value">${F.academia_clube||"Associação Goju-Ryu Karate Kai"}</span>
          </div>
          <div class="field">
            <span class="label">Peso / Altura</span>
            <span class="value">${F.fisico_peso?`${F.fisico_peso} kg`:"—"} / ${F.fisico_altura?`${F.fisico_altura} m`:"—"}</span>
          </div>
        </div>

        <div class="section-title">Informa\xe7\xf5es Pessoais</div>
        <div class="grid">
          <div class="field">
            <span class="label">CPF</span>
            <span class="value">${a}</span>
          </div>
          <div class="field">
            <span class="label">Data de Nascimento</span>
            <span class="value">${e} (Idade: ${s} anos)</span>
          </div>
          <div class="field">
            <span class="label">Sexo</span>
            <span class="value">${"M"===F.sexo?"Masculino":"F"===F.sexo?"Feminino":"Outro"}</span>
          </div>
          <div class="field">
            <span class="label">Celular</span>
            <span class="value">${F.telefone||"Não informado"}</span>
          </div>
          <div class="field grid-full">
            <span class="label">E-mail</span>
            <span class="value">${F.email}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Endere\xe7o Residencial</span>
            <span class="value">${F.endereco||"Não cadastrado"} ${F.cidade?`, ${F.cidade} - ${F.uf||"BA"}`:""}</span>
          </div>
        </div>

        ${t?`
        <div class="section-title">Respons\xe1vel Legal (Menor de 18 Anos)</div>
        <div class="grid">
          <div class="field grid-full">
            <span class="label">Nome do Respons\xe1vel</span>
            <span class="value">${F.responsavel_nome||"Não informado"}</span>
          </div>
          <div class="field">
            <span class="label">CPF do Respons\xe1vel</span>
            <span class="value">${r}</span>
          </div>
          <div class="field">
            <span class="label">Celular do Respons\xe1vel</span>
            <span class="value">${F.responsavel_telefone||"Não informado"}</span>
          </div>
          <div class="field grid-full">
            <span class="label">E-mail do Respons\xe1vel</span>
            <span class="value">${F.responsavel_email||"Não informado"}</span>
          </div>
        </div>
        `:""}

        <div class="section-title">Ficha M\xe9dica & Dados de Sa\xfade</div>
        <div class="grid">
          <div class="field">
            <span class="label">Tipo Sangu\xedneo & Fator Rh</span>
            <span class="value">${F.medico_tipo_sanguineo||"—"} ${F.medico_fator_rh||""}</span>
          </div>
          <div class="field">
            <span class="label">Cart\xe3o do SUS</span>
            <span class="value">${F.medico_sus||"Não informado"}</span>
          </div>
          <div class="field">
            <span class="label">Plano de Sa\xfade / Conv\xeanio</span>
            <span class="value">${F.medico_plano||"Sem informações de convênio médico."}</span>
          </div>
          <div class="field">
            <span class="label">Contato de Emerg\xeancia</span>
            <span class="value">${F.medico_emergencia_nome||"—"} ${F.medico_emergencia_telefone?`(${F.medico_emergencia_telefone})`:""}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Alergias Gerais & Alimentares</span>
            <span class="value">${F.medico_alergias||"Nenhuma alergia relatada."}</span>
          </div>
          <div class="field grid-full">
            <span class="label font-bold text-red-700">Alergia a Medicamentos</span>
            <span class="value">${F.medico_alergia_medicamento||"Nenhuma alergia a medicamentos relatada."}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Medicamentos de Uso Cont\xednuo</span>
            <span class="value">
              <strong>Usa medicamentos?</strong> ${F.medico_medicacao_uso||"Não"}<br/>
              ${"Sim"===F.medico_medicacao_uso?`<strong>Lista:</strong> ${F.medico_medicacao_lista}`:""}
            </span>
          </div>
          <div class="field grid-full">
            <span class="label">Restri\xe7\xf5es F\xedsicas / Recomenda\xe7\xf5es M\xe9dicas</span>
            <span class="value value-large">${F.medico_restricoes||"Nenhuma restrição física relatada."}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Diagn\xf3sticos Cl\xednicos / Patologias</span>
            <span class="value value-large">${F.medico_diagnosticos||"Nenhum diagnóstico relatado."}</span>
          </div>
        </div>

        <div class="section-title">Checklist de Documentos Exigidos (Controle Administrativo)</div>
        <div style="display: flex; justify-content: space-between; font-size: 8px; font-weight: bold; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 5px; padding: 8px 12px; margin-bottom: 10px;">
          <label style="display: flex; align-items: center; gap: 4px;"><input type="checkbox" style="transform: scale(0.85);" /> C\xf3pia do RG</label>
          <label style="display: flex; align-items: center; gap: 4px;"><input type="checkbox" style="transform: scale(0.85);" /> C\xf3pia RG do Respons\xe1vel (se menor)</label>
          <label style="display: flex; align-items: center; gap: 4px;"><input type="checkbox" style="transform: scale(0.85);" /> C\xf3pia do Cart\xe3o SUS</label>
          <label style="display: flex; align-items: center; gap: 4px;"><input type="checkbox" style="transform: scale(0.85);" /> C\xf3pia Cart\xe3o do Plano</label>
          <label style="display: flex; align-items: center; gap: 4px;"><input type="checkbox" style="transform: scale(0.85);" /> C\xf3pia Comprovante de Resid\xeancia</label>
        </div>

        <div class="section-title">Regras Gerais e Compromisso do Aluno (GRKK / Projeto Social)</div>
        <div style="font-size: 8px; line-height: 1.4; color: #222; background: #fff; border: 1px solid #ccc; border-radius: 5px; padding: 8px 12px; margin-bottom: 10px;">
          <ol class="list-rules">
            <li>Cada aluno dever\xe1 ter seu Karate-Gi (Kimono).</li>
            <li>O exame de faixa s\xf3 ser\xe1 permitido ao aluno com Karate-Gi (Kimono).</li>
            <li>Para realizar o exame de faixa o aluno dever\xe1 ter no m\xednimo 75% de presen\xe7a nos treinos.</li>
            <li>Para realizar o exame de faixa o aluno dever\xe1 ter no m\xednimo 75% de presen\xe7a Escolar.</li>
            <li>Para realizar o exame de faixa o aluno n\xe3o poder\xe1 ter m\xe9dia escolar inferior a 5,00.</li>
            <li>O aluno que for pego ou denunciado por agress\xe3o, viol\xeancia ou outro fator que venha a afetar a GRKK ser\xe1 suspenso e, se reincidente, ser\xe1 exclu\xeddo do projeto.</li>
            <li>Todos os custos administrativos como exames de faixa, campeonatos ou semin\xe1rios s\xe3o de inteira responsabilidade do aluno/respons\xe1vel.</li>
            <li><strong>Comodato:</strong> Em caso de desist\xeancia, o aluno dever\xe1 devolver imediatamente todo o material e uniforme fornecido sob regime de comodato para treino pela GRKK, para oportunizar a vaga a outra pessoa.</li>
          </ol>
        </div>

        <div class="section-title">Autoriza\xe7\xe3o de Uso de Imagem</div>
        <div style="font-size: 8px; line-height: 1.4; color: #222; background: #fff; border: 1px solid #ccc; border-radius: 5px; padding: 8px 12px; margin-bottom: 10px;">
          <p style="margin: 0 0 6px 0;">
            Ao assinar esta ficha, declaro ci\xeancia e decis\xe3o a respeito do uso de imagem para fins institucionais e de divulga\xe7\xe3o da GRKK, conforme escolha registrada abaixo:
          </p>
          <div style="display: flex; gap: 30px; font-weight: bold; font-size: 8.5px; text-transform: uppercase;">
            <span style="color: ${!1!==F.autoriza_uso_imagem?"#10b981":"#777"}">
              [${!1!==F.autoriza_uso_imagem?"X":" "}] Autorizo o uso da imagem.
            </span>
            <span style="color: ${!1===F.autoriza_uso_imagem?"#ef4444":"#777"}">
              [${!1===F.autoriza_uso_imagem?"X":" "}] N\xe3o autorizo o uso da imagem.
            </span>
          </div>
        </div>

        <div class="signature-area">
          <div class="signature-box">
            <div class="signature-line">Assinatura do Atleta (ou Respons\xe1vel Legal se menor)</div>
          </div>
          <div class="signature-box">
            <div class="signature-line">Assinatura do Sensei Respons\xe1vel</div>
          </div>
        </div>
      </body>
      </html>
    `),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},500)))},className:"px-5 py-2.5 bg-gold hover:bg-gold-dark text-white rounded-xl text-xs font-bold uppercase tracking-wider font-cinzel transition cursor-pointer flex items-center gap-1.5 shadow-lg shadow-gold/10",children:[(0,a.jsx)(p.Printer,{size:13}),"Imprimir Ficha"]}),(0,a.jsx)("button",{onClick:()=>P(null),className:"px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs font-bold uppercase tracking-wider font-cinzel transition cursor-pointer",children:"Fechar Ficha"})]})]})})]})}])}]);